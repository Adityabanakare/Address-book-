#include <stdio.h>
#include "file.h"
#include<string.h>
#include "contact.h"
void saveContactsToFile(AddressBook *addressBook)                     //Function to save contacts to a file(contacts.csv)
{
    //Bubble sort to sort contacts by name in alphabetical order
    for(int i = 0; i < addressBook->contactCount - 1; i++)
    {
        for(int j = 0; j < addressBook->contactCount - i - 1; j++)
        {
            if(strcasecmp(addressBook->contacts[j].name, addressBook->contacts[j + 1].name) > 0)               //Compare two names
            {
                //Swap contacts if they are not in the correct order
                Contact temp = addressBook->contacts[j];
                addressBook->contacts[j] = addressBook->contacts[j + 1];
                addressBook->contacts[j + 1] = temp;
            }   
        }
    }
    FILE *fp;                       
    fp = fopen("contacts.csv","w");                         //Open file in write mode to save contacts
    if(fp == NULL)
    {
        printf("Error opening file.\n");
        return;
    } 
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fp,"%s,%s,%s\n",addressBook->contacts[i].name,
                                addressBook->contacts[i].phone,             //It will print each contact to the file in CSV format
                                addressBook->contacts[i].email);
    }
    fclose(fp);                 //Close the file after writing
}

void loadContactsFromFile(AddressBook *addressBook)                             //Function to load contacts from a file
{
    FILE *fp;
    fp = fopen("contacts.csv","r");                                            //Open the file in read mode
    addressBook->contactCount = 0;                                              //Reset contact count to 0 before loading
    while(fscanf(fp, "%[^,],%[^,],%[^\n]\n",addressBook->contacts[addressBook->contactCount].name,
                                            addressBook->contacts[addressBook->contactCount].phone,         //It will read each line from the file and parse(extract) the contact details
                                            addressBook->contacts[addressBook->contactCount].email) == 3)
    {
        addressBook->contactCount++;                       //Increment contact count after successfully reading a contact
    }
    fclose(fp);                                            //Close the file after raeding
}