#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "ctype.h"

void initialize(AddressBook *addressBook)      //Function to initialize the addressbook
{
    addressBook->contactCount = 0;             //Initialize contact count to 0;   
    loadContactsFromFile(addressBook);        // Load contacts from file during initialization (After files)
}

int name_validate(AddressBook *addressBook, char *name)        //Function to validate the name
{
    //step1 : Fetch one by one character till null character
    for(int i = 0; name[i] != '\0'; i++)
    {
        if(!isalpha(name[i]) && name[i] != ' ')                //Check if the character is not an alphabet or space
        {
            return 1;                                          //Return 1 if invalid character found
            //step2 : Check the character is alphabet or not
            //yes->Move to next character, No->Stop the process
        }
    }
    return 0;                                                   //Return 0 if all characters are valid
}

int phone_validate(AddressBook *addressBook, char *phone)          //Function to validate phone number
{
   int i = 0;
   while(phone[i] != '\0')                                         //Traverse through each character in phone number
   {
        if(!(isdigit(phone[i])))                                   //check if the character is digit or not
        {
           return 1;                                               //Return 1 if invalid character found
        }
        i++;
   }
   if(i != 10)                                     //Check if phone number length is exactly 10 digits
   {
       return 1;                                   //Return 1 if phone number is not 10 digits long
   }
   return 0;                                       //Return 0 if phone number is valid
}

int unique_phone(AddressBook *addressBook,char *phone)                   //Function to check if the phone number is unique
{
    for(int i = 0; i < addressBook->contactCount; i++)                  //Traverse through all contacts
    {
        if(strcmp(addressBook->contacts[i].phone,phone) == 0)          //Compare the current phone number with existing ones
        {
            return 0;                                                 //Return 0 if the phone number already exits
        }
    }
    return 1;                                                       //Return 1 if the phone number is unique
}

int email_validate(AddressBook *addressBook, char *email)         //Function to validate the email address
{
    if(!(strstr(email,"@gmail.com")))                            //Check if email contains "@gmail.com"
    {
        return 1;                                             //Return 1 if email is not valid
    }
    return 0;                                                //Return 0 if email is valid
}

int unique_email(AddressBook *addressBook, char *email)                 //Function to check if the email address is unique
{
    for(int i = 0; i < addressBook->contactCount; i++)                 //Traverse through all contacts
    {
        if(strcmp(addressBook->contacts[i].email,email) == 0)          //Compare the current email with existing ones
        {
            return 0;                                                  //Return 0 if the email already exists
        }
    }
    return 1;                                                          //Return 1 if the email is unique
}
void createContact(AddressBook *addressBook)                   //Function to create a new contact and save it to the addressbook
{
	/* Define the logic to create a Contacts */
    char name[50];                                          //Declare a variable to store the name

    //step1 : Read a name from user
    printf("Enter the name: ");
   // --fpurge(stdin);
    //getchar;
    scanf(" %[^\n]",name);                                   //Read name input from the user

    //step2 : Validate the name -> Alphabets and space
    while(name_validate(addressBook, name) == 1)
    {
        printf("INFO: Name validation not done, Please enter valid name...\n");
        printf("Enter the name: ");
        scanf(" %[^\n]",name);                                          //Again tell user to re-enter a valid name
        //True->Go to step3, False->print error, Go to step1
    }

    //step3: Read a mobile number from user
    char phone[20];                                                   //Declare a variable to store the phone number
    printf("Enter the mobile number: ");
    scanf(" %[^\n]",phone);                                          //Read phone number input from the user

    //step4: validate the mobile number -> 10 digits & digits & unique
    while((phone_validate(addressBook, phone)) == 1 || !unique_phone(addressBook,phone) == 1)
    {
        if(phone_validate(addressBook, phone) == 1)
        {
            printf("INFO: Mobile number validation not done, Please enter valid mobile number...\n");
        }
        else 
        {
            printf("INFO: Mobile number already exists, Please enter a unique mobile number...\n");
        }
        printf("Enter the mobile number: ");
        scanf(" %[^\n]",phone);                                    //Again tell user to re-enter a valid or unique phone number
        //True->Go to step5, False->print error, Go to step3
    }

    //step5: Read a email_id from user
    char email[50];                                             //Declare a variable to store the email id
    printf("Enter the email_id: ");
    scanf(" %[^\n]",email);                                    //Read email input from the user

    //step6: Validate the email_id -> @gmail.com & unique
    while((email_validate(addressBook, email)) == 1 || !unique_email(addressBook,email) == 1)
    {
        if(email_validate(addressBook, email) == 1)
        {
            printf("INFO: email_id validation not done, Please enter valid email_id...\n");
        }
        else
        {
            printf("INFO: email_id already exists, Please enter a unique email_id...\n");
        }
        printf("Enter the email_id: ");
        scanf(" %[^\n]",email);                                       //Again tell user to re-enter a valid or unique email id
        //True-> Go to step7, False->print error, Go to step5
    }
    //step7: Store into structure contact_count
    strcpy(addressBook->contacts[addressBook->contactCount].name, name);
    strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
    strcpy(addressBook->contacts[addressBook->contactCount].email, email);
    addressBook->contactCount++;                                         //Increment the contact count after adding a new contact
    printf("Contact saved successfully\n");
}

 
int searchbyname(AddressBook *addressBook)                        //Function to search for a contact by name
{
    char partialchoice;
    while(1)                   //Start an infinite loop to ask for valid input
    {
        printf("Do you wish to enter a partial name? (y/n): ");      //Ask the user if they want to perform partial name serach(yes/no)
        scanf(" %c", &partialchoice);  
        while (getchar() != '\n');                      //clear the input buffer to handle extra characters
        if(partialchoice == 'y' || partialchoice == 'Y' || partialchoice == 'n' || partialchoice == 'N')       //check if the user entered a valid choice
        {
            break;                                      //Exit the loop if valid input is provided
        }
        else
        {
            printf("Invalid choice...\n");
        }
    }
    char name[50];
    printf("Enter the name to search: ");
    scanf(" %[^\n]", name);  
    while (name_validate(addressBook, name) == 1)
    {
        printf("Invalid name...\n");
        printf("Please enter a valid name: ");
        scanf(" %[^\n]", name);
    }
    Contact foundcontacts[MAX_CONTACTS];                         // Array to store found contacts
    int found = 0;                                               //Counter for the number of contacts found
    int foundindex = -1;                                          //Index of the found contact(if exactly one is found)
    int i;                                                
    if (partialchoice == 'y' || partialchoice == 'Y')                 //If user wants to search with a partial name  
    {
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcasestr(addressBook->contacts[i].name, name))
            {
                foundcontacts[found++] = addressBook->contacts[i];
            }
        }
        if (found > 0)                                                        //If one or more contacts were found
        {
            printf("No exact match found. Showing suggestions based on your searched name:\n");
            for (i = 0; i < found; i++)
            {
                printf("%d. Name= %s, Mobile number= %s, Email= %s\n", i + 1, foundcontacts[i].name,       
                                                                              foundcontacts[i].phone,       //It will list the found contacts as suggestions
                                                                              foundcontacts[i].email);
            }
            printf("Enter the number of the contact you are looking for: ");                     //Ask the user to select the number which contact do you want
            int search;
            scanf("%d", &search);
            if(search > 0 && search <= found)                                  //If the selected contact number is valid
            {
                foundindex = -1;                                                  //Reset found index
                for(i = 0; i < addressBook->contactCount; i++)               //Loop through all contacts in the address book to find the exact match
                {
                    if(strcasecmp(addressBook->contacts[i].name,foundcontacts[search - 1].name) == 0 &&
                        strcmp(addressBook->contacts[i].phone, foundcontacts[search - 1].phone) == 0)        //If the name and phone number match the selected suggestion
                    {
                        foundindex = i;                                   //Store the index of the matching contact
                        break;
                    }
                }
                if (foundindex != -1)                                      //If a matching contact was found,display it
                {
                    printf("You searched contact is found at index[%d]: Name= %s, Mobile number= %s, Email= %s\n",i,
                                                               addressBook->contacts[foundindex].name,
                                                               addressBook->contacts[foundindex].phone,
                                                               addressBook->contacts[foundindex].email);
                    return foundindex;                     //Return the index of the found contact
                }
            }
            else
            {
                printf("No contact found.\n");
                return -1;                      //Return -1 if no match(if the selected contact number is invalid)
            }
        }
        else
        {
            printf("No contact found\n");
            return -1;                       //Return -1 if no contacts were found with partial name
        }
    }
    else if (partialchoice == 'n' || partialchoice == 'N')                 //If user wants to search with a single contact name
    {
        for (i = 0; i < addressBook->contactCount; i++)
        {
            if (strcasecmp(addressBook->contacts[i].name, name) == 0)            //perform an exact match for the entered name
            {
                found++;                                                   //Increment the found counter
                foundindex = i;                                           //Store the index of the found contact
            }
        }
        if (found == 1 )                                //If exactly one contact was found
        {
            printf("You searched contact is found at index[%d]: Name= %s, Mobile number= %s, Email= %s\n",i,
                                                          addressBook->contacts[foundindex].name, 
                                                          addressBook->contacts[foundindex].phone, 
                                                          addressBook->contacts[foundindex].email);
            return foundindex;                                       //Return the index of the found contact
        }
        else if (found > 1)                                         //If multiple contacts found with the same name
        {
            char mobile[20];
            printf("Multiple contacts found with the same name. Please enter the mobile number: ");
            scanf(" %[^\n]", mobile);
            for (i = 0; i < addressBook->contactCount; i++)
            {
                if (strcasecmp(addressBook->contacts[i].name, name) == 0 && 
                    strcmp(addressBook->contacts[i].phone, mobile) == 0)
                {
                    printf("You searched contact is found at index[%d]: Name= %s, Mobile number= %s, Email= %s\n",i,
                                                                        addressBook->contacts[i].name, 
                                                                        addressBook->contacts[i].phone, 
                                                                        addressBook->contacts[i].email);
                    return i;                               //Return the index of the found contact
                }
            }
            printf("No contact found with the given mobile number.\n");
            return -1; 
        }
        else
        {
            printf("No contact found with the exact name '%s'.\n", name);
            return -1;  
        }
    }
    return -1;                        //Return -1 in case of an error or no result
}
    
int searchbyphone(AddressBook *addressBook)               //Function to search a contact by mobile number
{
    char phone[20];
    printf("Enter the mobile number to search : ");
    scanf(" %[^\n]",phone);
    while(phone_validate(addressBook, phone) == 1)
    {
        printf("Invalid mobile number...\n");
        printf("Please enter the valid mobile number: ");
        scanf(" %[^\n]",phone);
    }
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(addressBook->contacts[i].phone, phone) == 0)                     //If a match is found for the mobile number
        {
            printf("Contact found at index[%d]: Name= %s, Mobile number= %s, Email= %s\n",i,
                                               addressBook->contacts[i].name,
                                               addressBook->contacts[i].phone,
                                               addressBook->contacts[i].email);
            return i;                                                              //Return the index of the found contact
        }
    }
    printf("Contact not found\n");
    return -1;
}

int searchbyemail(AddressBook *addressBook)                                 //Function to search a contact by email address
{
    char email[50];
    printf("Enter the email_id to serach : ");
    scanf(" %[^\n]",email);
    while(email_validate(addressBook, email) == 1)
    {
        printf("Invalid email_id...\n");
        printf("Please enter the valid email_id: ");
        scanf(" %[^\n]",email);
    }
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(addressBook->contacts[i].email, email) == 0)                    //If a match is found for the email
        {
            printf("Contact found at index[%d]: Name= %s, Mobile number= %s, Email= %s\n",i,
                                                              addressBook->contacts[i].name,
                                                              addressBook->contacts[i].phone,
                                                              addressBook->contacts[i].email);
            return i;                            //Return the index of the found contact
        }   
    }
    printf("Contact not found\n");
    return -1;
}
void searchContact(AddressBook *addressBook) 
{
    /* Define the logic for search */
    //Step1: Print the menu based on what searching 
    //step2: choose the menu
    int choice;
    do
    {
        printf("\nSearch choice menu :\n");
        printf("1. Name\n");
        printf("2. Mobile number\n");
        printf("3. Email\n");
        printf("4. Exit\n");
        printf("Choose an option : ");
        scanf("%d",&choice);
    
        if(choice == 4)                   //Exit if user chooses option 4
        {
           return;
        } 

        switch(choice)
        {
            case 1:                                                         
                searchbyname(addressBook);                  //Call function to search by name                               
                break;

            case 2:
                searchbyphone(addressBook);                  //Call function to search by mobile number
                break;

            case 3:
                searchbyemail(addressBook);                  //Call function to search by email
                break;      
        
            default:
                printf("Invalid choice. Please try again...\n"); 
                continue;     
        }
    }
    while(1);                        //Repeat until the user exits
}
    
    
void editContact(AddressBook *addressBook)
{
	/* Define the logic for Editcontact */
    /* Define the logic for search */
    //Step1: Print the menu based on what searching 
    //step2: choose the menu
    int choice;
    int found= -1;                            //Variable to track if a contact is found
    do
    {
        printf("\nSearch choice menu :\n");
        printf("1. Name\n");
        printf("2. Mobile number\n");
        printf("3. Email\n");
        printf("4. Exit\n");
        printf("Choose an option : ");
        scanf("%d",&choice);
    
        if(choice == 4)
        {
            return;
        }

        switch(choice)
        {
            case 1:                                                         
                found = searchbyname(addressBook);              //Call function to search by name                         
                break;

            case 2:
                found = searchbyphone(addressBook);            //Call function to search by mobile number
                break;

            case 3:
                found = searchbyemail(addressBook);            //Call function to search by email
                break;      
        
            default:
                printf("Invalid choice. Please try again...\n"); 
                continue;               
        }
        if (found == -1)                          //If no contact found,continue searching
        {
            continue;   
        }
        printf("\nWhich field would you like to edit?\n");          //Once the contact is found,ask for which field to edit
        printf("1. Name\n");
        printf("2. Mobile number\n");
        printf("3. Email\n");
        printf("Choose an option: \n");
        int editchoice;
        scanf("%d",&editchoice);

        switch(editchoice)
        {
            case 1:
                {
                    char newname[50];
                    printf("Enter new name: ");
                    scanf(" %[^\n]",newname);
                    while(name_validate(addressBook,newname) == 1)
                    {
                        printf("INFO: Name validation not done, Please enter valid name...\n");
                        printf("Enter the new name: ");
                        scanf(" %[^\n]", newname);
                    }
                    strcpy(addressBook->contacts[found].name, newname);              //update name
                    break;
                }

            case 2:
                {
                    char newphone[20];
                    printf("Enter new mobile number: ");
                    scanf(" %[^\n]",newphone);
                    while(phone_validate(addressBook,newphone) == 1 || 
                          !unique_phone(addressBook,newphone) == 1)
                    { 
                        if(phone_validate(addressBook, newphone) == 1)
                        {
                            printf("INFO: Mobile number validation not done, Please enter valid mobile number...\n");
                        }
                        else
                        {
                            printf("INFO: Mobile number already exists, Please enter a unique mobile number...\n");
                        }
                        printf("Enter the new mobile number: ");
                        scanf(" %[^\n]",newphone);
                    }
                    strcpy(addressBook->contacts[found].phone, newphone);                 // update mobile number
                    break;
                }  
                    
            case 3:
                {
                    char newemail[50];
                    printf("Enter new email: ");
                    scanf(" %[^\n]", newemail);
                    while((email_validate(addressBook, newemail)) == 1 || 
                          !unique_email(addressBook,newemail) == 1)
                    {
                        if(email_validate(addressBook, newemail) == 1)
                        {
                            printf("INFO: email_id validation not done, Please enter valid email_id...\n");
                        }
                        else
                        {
                            printf("INFO: email_id already exists, Please enter a unique email_id...\n");
                        }
                        printf("Enter the new email: ");
                        scanf(" %[^\n]",newemail);
                    }
                    strcpy(addressBook->contacts[found].email, newemail);                   //update email
                    break;
                }
            
            default:
                printf("Invalid choice. Please try again...\n");
        }
        printf("Contact updated successfully\n");              
    }
    while(1);                          //Exit if users chooses option 4
}

           
void deleteContact(AddressBook *addressBook)
{
	/* Define the logic for deletecontact */
    /* Define the logic for search */
    //Step1: Print the menu based on what searching 
    //step2: choose the menu
    int choice;
    int found = -1;                                          //Variable to track if a contact is found
    do
    {
        printf("\nSearch choice menu :\n");
        printf("1. Name\n");
        printf("2. Mobile number\n");
        printf("3. Email\n");
        printf("4. Exit\n");
        printf("Choose an option : ");
        scanf("%d",&choice);
    
        if(choice == 4)
        {
            return;
        }

        switch(choice)
        {
            case 1:                                                         
                found = searchbyname(addressBook);                           //Call function to search by name 
                break;

            case 2:
                found = searchbyphone(addressBook);                          //Call function to search by phone number 
                break;

            case 3:
                found = searchbyemail(addressBook);                         //Call function to search by email
                break;      
        
            default:
                printf("Invalid choice. Please try again...\n"); 
                continue;               
        }
        if (found == -1) 
        {
           continue;   
        }
        char confirm;
        printf("Are you sure you want to delete this contact? (Y/N): ");
        scanf(" %c",&confirm);
        if(confirm == 'Y' || confirm == 'y')                                 //If the user confirms deletion
        {            
        for(int j = found; j < addressBook->contactCount - 1;j++)             //Shift all subsequent contacts one position up in the array
        {
            addressBook->contacts[j] = addressBook->contacts[j + 1];            //Shift contacts
        }
        addressBook->contactCount--;                                  //Reduce the contact count       
        printf("Contact deleted successfully\n");
        }
        else
        {
            printf("Deletion canceled\n");
        }
    }
    while(1);            //Exit if user chooses option 4
}

       
void listContacts(AddressBook *addressBook) 
{
    // Sort contacts based on the chosen criteria
    if(addressBook->contactCount == 0)           //Check if the address book is empty
    {
        printf("No contacts Found\n");
        return;
    }
     //Bubble sort to sort contacts by name in alphabetical order
    for(int i = 0; i < addressBook->contactCount - 1; i++)
    {
        for(int j = 0; j < addressBook->contactCount - i - 1; j++)
        {
            if(strcasecmp(addressBook->contacts[j].name, addressBook->contacts[j + 1].name) > 0)            //Compare two contact's names
            {
                Contact temp = addressBook->contacts[j];                                        //Store the current contact in a temporary variable 
                addressBook->contacts[j] = addressBook->contacts[j + 1];                        //Swap the contacts
                addressBook->contacts[j + 1] = temp;
            }  
        }
    }
    printf("Contacts Found : \n");
    printf("Sl.No\tName\t\t\t\tPhone Number\tEmail\n");
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        printf("%d\t%-30s\t%s\t%-50s\t\n", i+1,
                    addressBook->contacts[i].name,                             //It display all saved contacts
                    addressBook->contacts[i].phone,
                    addressBook->contacts[i].email);
    }
    return ;
}
